DROP database if exists YoutubeDatabase;
CREATE DATABASE YoutubeDatabase;
USE YoutubeDatabase;

CREATE TABLE videos(
	video_id varchar(100) PRIMARY KEY,
    title VARCHAR(100),
    thumbnail VARCHAR(100)
);

CREATE TABLE category(
	category_id VARCHAR(100) PRIMARY KEY,
    category_title VARCHAR(500)
);

CREATE TABLE videoinfo(
	video_id VARCHAR(100) PRIMARY KEY,
    publisher_at VARCHAR(100),
    channel_id VARCHAR(100),
    descriptions TEXT,
    tag TEXT,
    category_id VARCHAR(100),
    CONSTRAINT FK_video_id FOREIGN KEY(video_id) REFERENCES videos(video_id),
    CONSTRAINT FK_category_id FOREIGN KEY(category_id) REFERENCES category(category_id)
);

INSERT INTO category(category_id)
VALUES 
('1'),
('2'),
('3'),
('4'),
('5'),
('6'),
('7'),
('8'),
('9'),
('10'),
('11'),
('12'),
('13'),
('14'),
('15'),
('16'),
('17'),
('18'),
('19'),
('20'),
('21'),
('22'),
('23'),
('24'),
('25'),
('26'),
('27'),
('28'),
('29'),
('30'),
('31'),
('32'),
('33')












