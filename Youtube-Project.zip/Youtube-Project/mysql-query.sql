CREATE DATABASE YoutubeDatabase;
USE YoutubeDatabase;

CREATE TABLE videos(
	video_id varchar(1000) PRIMARY KEY,
    title VARCHAR(1000),
    thumbnail VARCHAR(1000)
);