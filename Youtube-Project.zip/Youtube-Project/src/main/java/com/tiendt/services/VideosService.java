package com.tiendt.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Component;

import com.tiendt.dao.VideosDao;
import com.tiendt.entity.Videos;

public class VideosService {
  
  private List<Videos> listVideos;
  VideosDao videosDao = new VideosDao();
  public List<Videos> getAllVideos() {
    try {
      listVideos = videosDao.getAllVideos();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    
    return listVideos;
  }
  
}
