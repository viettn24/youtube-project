package com.tiendt.config;

import java.beans.PropertyVetoException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
@EnableWebMvc
@ComponentScan("com.tiendt")
@PropertySource("classpath:persistence-mysql.properties")
public class WebXmlConfig {

    @Autowired
    private Environment env;
    
    @Bean
    public ViewResolver viewResolver() {
      InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
      viewResolver.setPrefix("/WEB-INF/view/");
      viewResolver.setSuffix(".jsp");
      return viewResolver;
      
    }
    
    @Bean
    public DataSource theDataSource() {
      ComboPooledDataSource theDataSource = new ComboPooledDataSource();
      
      try {
        theDataSource.setDriverClass(env.getProperty("jdbc.Driver"));
      } catch (PropertyVetoException exc) {
        throw new RuntimeException(exc);
      }
      
        theDataSource.setJdbcUrl(env.getProperty("jdbc.url"));
        theDataSource.setUser(env.getProperty("jdbc.user"));
        theDataSource.setPassword(env.getProperty("jdbc.pass"));
      
        
        theDataSource.setInitialPoolSize(convertInt("connection.pool.initalPoolSize"));
        theDataSource.setMinPoolSize(convertInt("connection.pool.minPoolSize"));
        theDataSource.setMaxPoolSize(convertInt("connection.pool.maxPoolSize"));
        theDataSource.setMaxIdleTime(convertInt("connection.pool.maxIdleTime"));
        
        
      
      return theDataSource;
      
    }
    
    public int convertInt(String poolProperty) {
      String envPro = env.getProperty(poolProperty);
      
      int envInt = Integer.parseInt(envPro);    
      
      return envInt;
    }
    
    
    
    
    
    
    
    
    
    
}
