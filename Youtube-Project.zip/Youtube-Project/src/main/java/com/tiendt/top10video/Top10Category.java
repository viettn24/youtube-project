package com.tiendt.top10video;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.tiendt.entity.VideoInfo;
import com.tiendt.utils.ConnectorDB;

public class Top10Category {

  private List<VideoInfo> listVideoInfo = new ArrayList<>();

  public List<VideoInfo> getTop10Category24() {

    // Giai tri category
    Connection conn = ConnectorDB.getConnection();
    String sqlSelectTop10Category24 = "SELECT vi.video_id, vi.publisher_at, vi.channel_id, vi.descriptions, vi.tag, vi.category_id, v.title FROM youtubedatabase.videoinfo AS vi LEFT JOIN youtubedatabase.videos AS v ON (v.video_id = vi.video_id) WHERE vi.category_id=24 ORDER BY RAND() LIMIT 8;";
    try {
      PreparedStatement pstmt = conn.prepareStatement(sqlSelectTop10Category24);
      ResultSet rs = pstmt.executeQuery();
      while(rs.next()) {
        VideoInfo theVideoInfo = new VideoInfo();
        theVideoInfo.setVideoId(rs.getString("video_id"));
        theVideoInfo.setPublisherAt(rs.getString("publisher_at"));
        theVideoInfo.setChannelId(rs.getString("channel_id"));
        theVideoInfo.setDescriptions(rs.getString("descriptions"));
        theVideoInfo.setTags(rs.getString("tag"));
        theVideoInfo.setTitle(rs.getString("title"));
        
        listVideoInfo.add(theVideoInfo);
        
      }

    } catch (SQLException e) {
      // TODO Auto-generated catch block
    }

    return listVideoInfo;
  }
  
  
  public List<VideoInfo> getTop10Category24() {

    // Giai tri category
    Connection conn = ConnectorDB.getConnection();
    String sqlSelectTop10Category24 = "SELECT vi.video_id, vi.publisher_at, vi.channel_id, vi.descriptions, vi.tag, vi.category_id, v.title FROM youtubedatabase.videoinfo AS vi LEFT JOIN youtubedatabase.videos AS v ON (v.video_id = vi.video_id) WHERE vi.category_id=24 ORDER BY RAND() LIMIT 8;";
    try {
      PreparedStatement pstmt = conn.prepareStatement(sqlSelectTop10Category24);
      ResultSet rs = pstmt.executeQuery();
      while(rs.next()) {
        VideoInfo theVideoInfo = new VideoInfo();
        theVideoInfo.setVideoId(rs.getString("video_id"));
        theVideoInfo.setPublisherAt(rs.getString("publisher_at"));
        theVideoInfo.setChannelId(rs.getString("channel_id"));
        theVideoInfo.setDescriptions(rs.getString("descriptions"));
        theVideoInfo.setTags(rs.getString("tag"));
        theVideoInfo.setTitle(rs.getString("title"));
        
        listVideoInfo.add(theVideoInfo);
        
      }

    } catch (SQLException e) {
      // TODO Auto-generated catch block
    }

    return listVideoInfo;
  }

}
