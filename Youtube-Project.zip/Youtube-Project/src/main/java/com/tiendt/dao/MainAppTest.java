package com.tiendt.dao;

import java.io.IOException;
import java.net.URL;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tiendt.entity.AvideoCass1;

public class MainAppTest {

  public static void main(String[] args) {
    OkHtpDao theOkHtpDao = new OkHtpDao();
    
    try {
      String content = theOkHtpDao.convertData("https://www.googleapis.com/youtube/v3/videos?part=id%2C+snippet&id=4Y4YSpF6d6w&key=AIzaSyCdDAMlGv_uffMGkMLlBUrDOyrkWMW6xZE");
      String url = "https://www.googleapis.com/youtube/v3/videos?part=id%2C+snippet&id=xLCn88bfW1o&key=AIzaSyCdDAMlGv_uffMGkMLlBUrDOyrkWMW6xZE";
      
      ObjectMapper objectMapper = new ObjectMapper();
      
      AvideoCass1 theVideos = objectMapper.readValue(new URL(url),AvideoCass1.class);
      
      System.out.println(theVideos.getItems()[0].getSnippet().getTitle());
      
      
    
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
  }

}
