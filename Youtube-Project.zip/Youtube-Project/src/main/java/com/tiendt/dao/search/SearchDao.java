package com.tiendt.dao.search;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.services.samples.youtube.cmdline.Auth;
import com.google.api.services.youtube.YouTube;
import com.google.api.services.youtube.model.ResourceId;
import com.google.api.services.youtube.model.SearchListResponse;
import com.google.api.services.youtube.model.SearchResult;
import com.google.api.services.youtube.model.Thumbnail;
import com.tiendt.dao.Search;
import com.tiendt.entity.AvideoCass1;
import com.tiendt.entity.Videos;
import com.tiendt.utils.ConnectorDB;

public class SearchDao {
	private final String PROPERTIES_FILENAME = "youtube.properties";
	private final long NUMBER_OF_VIDEOS_RETURNED = 25;
	private static YouTube youtube;
	public List<Videos> listVideos = new ArrayList<>();
	public List<Videos> tempListVideos = new ArrayList<>();
	public Videos videos;
	public Videos tempVideos = new Videos();

	
	
	public List<Videos> mainSearch(String theSearchName) {
        // Read the developer key from the properties file.
        Properties properties = new Properties();
        try {
            InputStream in = Search.class.getResourceAsStream("/" + PROPERTIES_FILENAME);
            properties.load(in);

        } catch (IOException e) {
            System.err.println("There was an error reading " + PROPERTIES_FILENAME + ": " + e.getCause()
                    + " : " + e.getMessage());
            System.exit(1);
        }

        try {
            // This object is used to make YouTube Data API requests. The last
            // argument is required, but since we don't need anything
            // initialized when the HttpRequest is initialized, we override
            // the interface and provide a no-op function.
            youtube = new YouTube.Builder(Auth.HTTP_TRANSPORT, Auth.JSON_FACTORY, new HttpRequestInitializer() {
                public void initialize(HttpRequest request) throws IOException {
                }
            }).setApplicationName("youtube-cmdline-search-sample").build();

            // Prompt the user to enter a query term.
            String queryTerm = theSearchName;

            // Define the API request for retrieving search results.
            YouTube.Search.List search = youtube.search().list("id,snippet");

            // Set your developer key from the {{ Google Cloud Console }} for
            // non-authenticated requests. See:
            // {{ https://cloud.google.com/console }}
            String apiKey = properties.getProperty("youtube.apikey");
            search.setKey(apiKey);
            search.setQ(queryTerm);

            // Restrict the search results to only include videos. See:
            // https://developers.google.com/youtube/v3/docs/search/list#type
            search.setType("video");

            // To increase efficiency, only retrieve the fields that the
            // application uses.
            search.setFields("items(id/kind,id/videoId,snippet/title,snippet/thumbnails/default/url)");
            search.setMaxResults(NUMBER_OF_VIDEOS_RETURNED);

            // Call the API and print results.
            SearchListResponse searchResponse = search.execute();
            List<SearchResult> searchResultList = searchResponse.getItems();
            System.out.println(searchResultList + "dsadsa hehehe-=====");
            if (searchResultList != null) {
                tempListVideos = prettyPrint(searchResultList.iterator(), queryTerm);
            }
        } catch (GoogleJsonResponseException e) {
            System.err.println("There was a service error: " + e.getDetails().getCode() + " : "
                    + e.getDetails().getMessage());
        } catch (IOException e) {
            System.err.println("There was an IO error: " + e.getCause() + " : " + e.getMessage());
        } catch (Throwable t) {
            t.printStackTrace();
        }
        
        return tempListVideos;
    }
	
	
	
//	private String getInputQuery() throws IOException {
//
//		String inputQuery = "";
//
//		System.out.print("Please enter a search term: ");
//		BufferedReader bReader = new BufferedReader(new InputStreamReader(System.in));
//		inputQuery = bReader.readLine();
//
//		if (inputQuery.length() < 1) {
//			// Use the string "YouTube Developers Live" as a default.
//			inputQuery = "YouTube Developers Live";
//		}
//		return inputQuery;
//	}

	private List<Videos> prettyPrint(Iterator<SearchResult> iteratorSearchResults, String query) {
		Connection conn = ConnectorDB.getConnection();

		System.out.println("\n=============================================================");
		System.out.println("   First " + NUMBER_OF_VIDEOS_RETURNED + " videos for search on \"" + query + "\".");
		System.out.println("=============================================================\n");

		if (!iteratorSearchResults.hasNext()) {
			System.out.println(" There aren't any results for your query.");

		}

		while (iteratorSearchResults.hasNext()) {

			SearchResult singleVideo = iteratorSearchResults.next();
			ResourceId rId = singleVideo.getId();

			// Confirm that the result represents a video. Otherwise, the
			// item will not contain a video ID.
			if (rId.getKind().equals("youtube#video")) {
				Thumbnail thumbnail = singleVideo.getSnippet().getThumbnails().getDefault();

				String saveYoutubeData = "INSERT INTO videos(video_id, title, thumbnail) VALUES(?,?,?)";
				try {
					PreparedStatement pstmt = conn.prepareStatement(saveYoutubeData);
					pstmt.setString(1, rId.getVideoId());
					pstmt.setString(2, singleVideo.getSnippet().getTitle());
					pstmt.setString(3, thumbnail.getUrl());
					pstmt.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				AvideoCass1 theVideos = null;
				try {
					String url = "https://www.googleapis.com/youtube/v3/videos?part=id%2C+snippet&id="
							+ rId.getVideoId() + "&key=AIzaSyCdDAMlGv_uffMGkMLlBUrDOyrkWMW6xZE";

					ObjectMapper objectMapper = new ObjectMapper();

					theVideos = objectMapper.readValue(new URL(url), AvideoCass1.class);

					System.out.println(theVideos.getItems()[0].getSnippet().getTitle());

				} catch (Exception e) {

				}

				String saveVideoInfo = "INSERT INTO videoinfo(video_id, publisher_at, channel_id, descriptions, tag, category_id) VALUES(?,?,?,?,?,?)";
				String tagList = "";

				try {
					PreparedStatement pstmtSaveVideoInfo = conn.prepareStatement(saveVideoInfo);
					pstmtSaveVideoInfo.setString(1, rId.getVideoId());
					pstmtSaveVideoInfo.setString(2, theVideos.getItems()[0].getSnippet().getPublishedAt());
					pstmtSaveVideoInfo.setString(3, theVideos.getItems()[0].getSnippet().getChannelId());
					pstmtSaveVideoInfo.setString(4, theVideos.getItems()[0].getSnippet().getDescription());

					if (theVideos.getItems()[0].getSnippet().getTags() != null) {

						for (String tempString : theVideos.getItems()[0].getSnippet().getTags()) {
							tagList = tagList + "," + tempString;
						}

					}

					pstmtSaveVideoInfo.setString(5, tagList);
					pstmtSaveVideoInfo.setString(6, theVideos.getItems()[0].getSnippet().getCategoryId());
					pstmtSaveVideoInfo.executeUpdate();

				} catch (SQLException e) {
					e.printStackTrace();
				}

				System.out.println(" Video Id" + rId.getVideoId());
				System.out.println(" Title: " + singleVideo.getSnippet().getTitle());
				System.out.println(" Thumbnail: " + thumbnail.getUrl());
				System.out.println("\n-------------------------------------------------------------\n");
				videos = new Videos();
				videos.setVideoId(rId.getVideoId());
				videos.setTitle(singleVideo.getSnippet().getTitle());
				videos.setThumbnail(thumbnail.getUrl());
				listVideos.add(videos);
			}
		}
		
		
		return listVideos;

	}

}
