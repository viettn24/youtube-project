package com.tiendt.dao;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import com.github.axet.vget.VGet;

public class TestVgetHihi {

	public static void main(String[] args) {
		
		String url = "https://www.youtube.com/watch?v=vWkUqM4zorw";
        String path = "F:";
        try {
			VGet v = new VGet(new URL(url), new File(path));
			v.download();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
