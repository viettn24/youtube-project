package com.tiendt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tiendt.entity.VideoInfo;
import com.tiendt.utils.ConnectorDB;

public class AppTestAhihi {

  public static void main(String[] args) throws SQLException {
    VideoInfo theVideoInfo = new VideoInfo();
    Connection conn = ConnectorDB.getConnection();
    String sqlGetVideoInfo = "SELECT * FROM videoinfo WHERE video_id = ?";
    PreparedStatement pstmt = conn.prepareStatement(sqlGetVideoInfo);
    pstmt.setString(1, "0LFuXK7aU6c");
    ResultSet rs = pstmt.executeQuery();
    while(rs.next()) {
      theVideoInfo.setVideoId(rs.getString("video_id"));
      theVideoInfo.setPublisherAt(rs.getString("publisher_at"));
      theVideoInfo.setChannelId(rs.getString("channel_id"));
      theVideoInfo.setDescriptions(rs.getString("descriptions"));
      System.out.println("==========aaaaaaaa==========="+ rs.getNString("descriptions")  + "============bbbbbbbbb===============");
      System.out.println("Thách thức danh hài ================");
      theVideoInfo.setTags(rs.getString("tag"));
      theVideoInfo.setCategoryId(rs.getString("category_id"));
      
    }

  }

}
