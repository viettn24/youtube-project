package com.tiendt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.tiendt.entity.VideoInfo;
import com.tiendt.entity.Videos;
import com.tiendt.utils.ConnectorDB;


public class VideosDao {
  
  private List<Videos> listVideos = new ArrayList<>();
  private Videos theVideos;
  public List<Videos> getAllVideos() throws SQLException{

    Connection conn = ConnectorDB.getConnection();
    
    String sqlGetAllVideo = "SELECT * FROM videos";
    PreparedStatement pstmt = conn.prepareStatement(sqlGetAllVideo);
    ResultSet rs = pstmt.executeQuery();
    while(rs.next()) {
      theVideos = new Videos();
      theVideos.setVideoId(rs.getString("video_id"));
      theVideos.setTitle(rs.getString("title"));
      theVideos.setThumbnail(rs.getString("thumbnail"));
      
      listVideos.add(theVideos);
    }
    
    
    return listVideos;
  }
  
  
  public VideoInfo getVideoInfo(String id) throws SQLException {
    VideoInfo theVideoInfo = new VideoInfo();
    Connection conn = ConnectorDB.getConnection();
    String sqlGetVideoInfo = "SELECT * FROM videoinfo WHERE video_id = ?";
    PreparedStatement pstmt = conn.prepareStatement(sqlGetVideoInfo);
    pstmt.setString(1, id);
    ResultSet rs = pstmt.executeQuery();
    while(rs.next()) {
      theVideoInfo.setVideoId(rs.getString("video_id"));
      theVideoInfo.setPublisherAt(rs.getString("publisher_at"));
      theVideoInfo.setChannelId(rs.getString("channel_id"));
      theVideoInfo.setDescriptions(rs.getString("descriptions"));
      System.out.println("==========aaaaaaaa==========="+ rs.getNString("descriptions")  + "============bbbbbbbbb===============");
      System.out.println("Thách thức danh hài ================");
      theVideoInfo.setTags(rs.getString("tag"));
      theVideoInfo.setCategoryId(rs.getString("category_id"));
      
    }
    
    
    return theVideoInfo;
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
}
