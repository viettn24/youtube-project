package com.tiendt.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tiendt.entity.Videos;
import com.tiendt.services.VideosService;

@Controller
public class HomeController {
  
  @RequestMapping("home.htm")
  public String home(Model theModel) {
    VideosService videosService = new VideosService();
    List<Videos> listVideos = videosService.getAllVideos();
    
    theModel.addAttribute("listVideos", listVideos);
    
    return "home";
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
}
