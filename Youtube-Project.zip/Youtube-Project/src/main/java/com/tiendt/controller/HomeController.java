package com.tiendt.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tiendt.entity.VideoInfo;
import com.tiendt.entity.Videos;
import com.tiendt.services.VideosService;
import com.tiendt.top10video.Top10Category;

@Controller
public class HomeController {
  
  VideosService videosService = new VideosService();
  
  @RequestMapping("home.htm")
  public String home(Model theModel) {
    
    Top10Category top10Category = new Top10Category();
    
    List<Videos> listVideos = videosService.getAllVideos();
    List<VideoInfo> listVideoInfo = top10Category.getTop10Category24();
    
    theModel.addAttribute("listVideos", listVideos);
    theModel.addAttribute("top10", listVideoInfo);
    
    return "home";
  }
  
  @RequestMapping("view.htm")
  public String viewVideo(@RequestParam("id") String id, Model theModel) {
//    @RequestParam("id") int id
    System.out.println(id);
    
    VideoInfo theVideoInfo = videosService.getVideoInfo(id);
    theModel.addAttribute("videoInfo", theVideoInfo);
    
    System.out.println(theModel);
    System.out.println(theVideoInfo);
    
    
    return "view-video";
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
}
