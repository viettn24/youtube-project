package com.tiendt.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.api.services.samples.youtube.cmdline.data.Search;
import com.tiendt.dao.search.SearchDao;
import com.tiendt.entity.VideoInfo;
import com.tiendt.entity.Videos;
import com.tiendt.services.VideosService;
import com.tiendt.top10video.Top10Category;

@Controller
public class HomeController {
  
	//https://themeforest.net/item/videopro-video-wordpress-theme/16677956?s_rank=6
  VideosService videosService = new VideosService();
  
  @RequestMapping("home.htm")
  public String home(Model theModel) {
    
    Top10Category top10Category = new Top10Category();
    
    List<Videos> listVideos = videosService.getAllVideos();
    List<VideoInfo> listVideoInfo24 = top10Category.getTop10Category24();
    List<VideoInfo> listVideoInfo1 = top10Category.getTop10Category1();
    
    
    
    theModel.addAttribute("listVideos", listVideos);
    theModel.addAttribute("top10cate24", listVideoInfo24);
    theModel.addAttribute("top10cate1", listVideoInfo1);
    
    return "home";
  }
  
  @RequestMapping("view.htm")
  public String viewVideo(@RequestParam("id") String id, Model theModel) {
//    @RequestParam("id") int id
    System.out.println(id);
    
    VideoInfo theVideoInfo = videosService.getVideoInfo(id);
    theModel.addAttribute("videoInfo", theVideoInfo);
    
    System.out.println(theModel);
    System.out.println(theVideoInfo);
    
    
    return "view-video";
  }
  
  @RequestMapping("searchHome.htm")
  public String searchHome(@RequestParam("theSearchName") String theSearchName, Model theModel) {
	  SearchDao theSearchDao = new SearchDao();
	  List<Videos> listVideos = new ArrayList<>();
	  
	  listVideos = theSearchDao.mainSearch(theSearchName);
	  theModel.addAttribute("listSearch", listVideos);
	  System.out.println(listVideos + "==============kkkkkkkkkkkk============");
	  
	  
	  
	  return "search-page";
  }
  
  
  
  
  
  
  
  
  
  
}
