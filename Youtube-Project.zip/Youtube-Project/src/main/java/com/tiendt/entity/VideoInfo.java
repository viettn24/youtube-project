package com.tiendt.entity;

public class VideoInfo {
  private String videoId;
  private String publisherAt;
  private String channelId;
  private String descriptions;
  private String tags;
  private String categoryId;
  private String title;
  public VideoInfo() {
  }
  public VideoInfo(String videoId, String publisherAt, String channelId,
      String descriptions, String tags, String categoryId, String title) {
    this.videoId = videoId;
    this.publisherAt = publisherAt;
    this.channelId = channelId;
    this.descriptions = descriptions;
    this.tags = tags;
    this.categoryId = categoryId;
    this.title = title;
  }
  public String getVideoId() {
    return videoId;
  }
  public void setVideoId(String videoId) {
    this.videoId = videoId;
  }
  public String getPublisherAt() {
    return publisherAt;
  }
  public void setPublisherAt(String publisherAt) {
    this.publisherAt = publisherAt;
  }
  public String getChannelId() {
    return channelId;
  }
  public void setChannelId(String channelId) {
    this.channelId = channelId;
  }
  public String getDescriptions() {
    return descriptions;
  }
  public void setDescriptions(String descriptions) {
    this.descriptions = descriptions;
  }
  public String getTags() {
    return tags;
  }
  public void setTags(String tags) {
    this.tags = tags;
  }
  public String getCategoryId() {
    return categoryId;
  }
  public void setCategoryId(String categoryId) {
    this.categoryId = categoryId;
  }
  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }
  @Override
  public String toString() {
    return "VideoInfo [videoId=" + videoId + ", publisherAt=" + publisherAt
        + ", channelId=" + channelId + ", descriptions=" + descriptions
        + ", tags=" + tags + ", categoryId=" + categoryId + ", title=" + title
        + "]";
  }
  
  
  
}
